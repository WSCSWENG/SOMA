import zope.deprecation
zope.deprecation.moved('pyramid.predicates', 'Pyramid 2.0')
