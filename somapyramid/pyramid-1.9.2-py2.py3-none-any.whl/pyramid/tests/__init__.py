
def dummy_extend(*args):
    """used to test Configurator.extend"""
