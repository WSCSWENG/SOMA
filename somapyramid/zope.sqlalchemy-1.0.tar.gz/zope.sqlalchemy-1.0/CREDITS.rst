zope.sqlalchemy credits
***********************

* Laurence Rowe - creator and main developer

* Martijn Faassen - updated to work with SQLAlchemy 0.5

Also thanks to Michael Bayer for help with integration in SQLAlchemy
and of course SQLAlchemy itself, as well as the many Zope developers
who worked on Zope/SQLAlchemy integration projects.
